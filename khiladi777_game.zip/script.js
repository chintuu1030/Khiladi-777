let coins = 1000;
let userBets = [];
let betType = "";
let timer = 30;
let countdown;

const timerDisplay = document.getElementById('timer');
const coinDisplay = document.getElementById('coin-balance');

function updateCoins(amount) {
  coins += amount;
  coinDisplay.textContent = coins;
}

const numberButtons = document.querySelectorAll('.number');
numberButtons.forEach(button => {
  button.addEventListener('click', () => {
    const num = parseInt(button.textContent);
    if (coins >= 10) {
      updateCoins(-10);
      userBets.push(num);
      alert(`Bet placed on number ${num}`);
    }
  });
});

document.querySelector('.big').addEventListener('click', () => {
  if (coins >= 10) {
    updateCoins(-10);
    betType = "Big";
    alert("Bet placed on Big");
  }
});

document.querySelector('.small').addEventListener('click', () => {
  if (coins >= 10) {
    updateCoins(-10);
    betType = "Small";
    alert("Bet placed on Small");
  }
});

function showResult() {
  const resultNum = Math.floor(Math.random() * 10);
  const size = resultNum < 5 ? "Small" : "Big";
  const winOnNumber = userBets.includes(resultNum);
  const winOnType = betType === size;

  if (winOnNumber) {
    updateCoins(20);
    alert(`You won on number ${resultNum}!`);
  } else if (winOnType) {
    updateCoins(20);
    alert(`You won on ${size} with number ${resultNum}!`);
  } else {
    alert(`You lost! Result was ${resultNum} - ${size}`);
  }

  addToHistory("20250417" + Math.floor(Math.random()*10000), resultNum, size);
  userBets = [];
  betType = "";
  timer = 30;
  countdown = setInterval(updateTimer, 1000);
}

function updateTimer() {
  if (timer > 0) {
    timer--;
    timerDisplay.textContent = `00:${timer < 10 ? '0' + timer : timer}`;
  } else {
    clearInterval(countdown);
    timerDisplay.textContent = "Time's Up!";
    showResult();
  }
}

function addToHistory(period, number, tag) {
  const historyList = document.getElementById('history-list');
  const li = document.createElement('li');
  li.innerHTML = `<span>Period:</span> ${period} - <span class="${getColor(number)}">${number}</span> - ${tag}`;
  historyList.prepend(li);
}

function getColor(num) {
  if (num === 0 || num === 5) return 'violet';
  if (num % 2 === 0) return 'red';
  return 'green';
}

window.onload = () => {
  const savedUser = localStorage.getItem('username');
  if (savedUser) {
    document.getElementById('main-app').style.display = 'block';
    document.getElementById('login-screen').style.display = 'none';
    showUsername(savedUser);
    countdown = setInterval(updateTimer, 1000);
  } else {
    document.getElementById('login-screen').style.display = 'flex';
  }
};

function login() {
  const username = document.getElementById('username-input').value.trim();
  if (username) {
    localStorage.setItem('username', username);
    document.getElementById('login-screen').style.display = 'none';
    document.getElementById('main-app').style.display = 'block';
    showUsername(username);
    countdown = setInterval(updateTimer, 1000);
  } else {
    alert("Please enter a name");
  }
}

function showUsername(name) {
  const header = document.querySelector('header');
  const userTag = document.createElement('p');
  userTag.textContent = `Welcome, ${name}!`;
  userTag.style.fontSize = "1rem";
  userTag.style.marginTop = "5px";
  header.appendChild(userTag);
}

function logout() {
  localStorage.removeItem('username');
  location.reload();
}